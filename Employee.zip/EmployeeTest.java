/*
Employee driver class
Brandon Tennyson
09/02/2018
this program demonstrated the use of a super class and inheritance, while demonstrating file input and output
*/
package employeetest;

import java.io.BufferedReader;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;


/**
 *
 * @author Brandon
 */
public class EmployeeTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        BufferedReader inputStream = null;
        readString("in.txt");

    }
    //this method reads in from a text file and seperates the words into arrays and uses them to seperate 
    // each obect to be created in the appropriate array and of the appropriate type.
    public static void readString(String file) throws FileNotFoundException {
        String txt = " ";
        try {
            File f = new File(file);
            Scanner in = new Scanner(new File(file));
            Employee[] employees14 = new Employee[10];
            Employee[] employees15 = new Employee[10];
            int count14 = 0;
            int count15 = 0;
            while (in.hasNextLine()) {
                txt = in.nextLine();
                String[] arr = txt.split(" ");

                if (arr[0].equals("2014")) {
                    if (arr[1].equals("Employee")) {
                        employees14[count14] = new Employee(arr[2], Double.parseDouble(arr[3]));
                        count14++;
                    } else {
                        if (arr[1].equals("Salesman")) {
                            employees14[count14] = new Salesman(arr[2], Double.parseDouble(arr[3]), Double.parseDouble(arr[4]));
                            count14++;
                        } else {
                            if (arr[1].equals("Executive")) {
                                employees14[count14] = new Executive(arr[2], Double.parseDouble(arr[3]), Double.parseDouble(arr[4]));
                                count14++;
                            }
                        }
                    }

                } else {
                    if (arr[0].equals("2015")) {
                        if (arr[1].equals("Employee")) {
                            employees15[count15] = new Employee(arr[2], Double.parseDouble(arr[3]));
                            count15++;
                        } else {
                            if (arr[1].equals("Salesman")) {
                                employees15[count15] = new Salesman(arr[2], Double.parseDouble(arr[3]), Double.parseDouble(arr[4]));

                                count15++;
                            } else {
                                if (arr[1].equals("Executive")) {
                                    employees15[count15] = new Executive(arr[2], Double.parseDouble(arr[3]), Double.parseDouble(arr[4]));

                                    count15++;
                                }
                            }
                        }

                    }
                }
            }

            for (int i = 0; i < count14; i++) {
                System.out.println(employees14[i].toString()
                        + " Annual Salary: " + employees14[i].getAnnualSalary() + "\n\n");
            }
            for (int i = 0; i < count15; i++) {
                System.out.println("Name: " + employees15[i].toString()
                        + "\n"
                        + "annual Salary: " + employees15[i].getAnnualSalary());
            }

        }
    catch(FileNotFoundException e){
        System.out.println("file not found");
    }
} 
}
