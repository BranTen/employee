/*
this method is the parent class for executve and salesman class 
*/
package employeetest;

/**
 *
 * @author Brandon
 */
public class Employee {

    double salary;
    private String name;

    public Employee(String name, double monthlySalary) {

        this.name = name;
        salary = monthlySalary;
    }

    public double getAnnualSalary() {
        double annualSalary = 0;
        annualSalary = salary * 12;
        return annualSalary;
    }

    public String toString() {
        // TODO Auto-generated method stub

        String str;
        str = "Name: " + name + "\n"
                + "Monthly Salary: " + salary + "\n";
        return str;
    }
}
