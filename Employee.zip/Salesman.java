package employeetest;

/**
 * this class is where the information is stored and where it calculates the
 * annual pay for the specific employee
 *
 * @author Brandon
 */
public class Salesman extends Employee {

    private double sales;
    private double annualSales;
    private double monthlySalary;
    private String name;

    public Salesman(String name, double monthlySalary, double annualSales) {
        super(name, monthlySalary);
        this.name = name;
        this.monthlySalary = monthlySalary;
        this.annualSales = annualSales;
    }

    public String toString() {
        return "Name: " + name + "\nMonthly Salary: " + monthlySalary + "\n";
    }

    public double getAnnualSalary() {
        double salary = monthlySalary * 12;
        return salary + (annualSales * 0.02);
    }

}
