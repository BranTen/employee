package employeetest;

/**
 * this class is where the information is stored and where it calculates the
 * annual pay for the specific employee
 *
 * @author Brandon
 */
public class Executive extends Employee {

    private double monthlySalary;
    private double stockPrice;
    private String name;

    public Executive(String name, double monthlySalary, double stockPrice) {
        super(name, monthlySalary);
        this.monthlySalary = monthlySalary;
        this.name = name;
        this.stockPrice = stockPrice;

    }

    public double getAnnualSalary() {
        double bonus = 0;
        if (stockPrice > 50) {
            bonus = 30000;
        }
        return (monthlySalary * 12) + bonus;
    }

    public String toString() {
        return "Name: " + name + "\nMonthly Salary: " + monthlySalary + "\nStock Price: " + stockPrice + "\n";

    }

}
